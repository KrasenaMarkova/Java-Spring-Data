package softuni.exam.models.entity.enums;

public enum Gender {

    M, F

    }
